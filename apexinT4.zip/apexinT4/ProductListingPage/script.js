const products = [
  {
    name: "Smartphone",
    category: "electronics",
    price: 899,
    rating: 4.5,
    image: "smartphone.webp"
  },
  {
    name: "Laptop",
    category: "electronics",
    price: 1500,
    rating: 4.8,
    image: "laptop.webp"
    
  },
  {
    name: "T-shirt",
    category: "fashion",
    price: 299,
    rating: 4.1,
    image: "tshirt.webp"
  },
  {
    name: "Blender",
    category: "home",
    price: 700,
    rating: 4.3,
    image: "blender.webp"
  },
  {
    name: "Sofa",
    category: "home",
    price: 2500,
    rating: 4.0,
    image: "sofa.webp"
  },
  {
    name: "Sneakers",
    category: "fashion",
    price: 1200,
    rating: 4.6,
    image: "sneakers.webp"
  }
];

const productList = document.getElementById("productList");
const categoryFilter = document.getElementById("categoryFilter");
const priceFilter = document.getElementById("priceFilter");
const sortOption = document.getElementById("sortOption");

function renderProducts(items) {
  productList.innerHTML = "";
  items.forEach(product => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <img src="${product.image}" alt="${product.name}" class="product-image" />
      <h3>${product.name}</h3>
      <div class="category">${product.category}</div>
      <div class="price">₹${product.price}</div>
      <div class="rating">⭐ ${product.rating}</div>
    `;
    productList.appendChild(div);
  });
}

function applyFiltersAndSort() {
  let filtered = [...products];

  const category = categoryFilter.value;
  const price = priceFilter.value;
  const sort = sortOption.value;

  if (category !== "all") {
    filtered = filtered.filter(p => p.category === category);
  }

  if (price === "low") {
    filtered = filtered.filter(p => p.price < 500);
  } else if (price === "mid") {
    filtered = filtered.filter(p => p.price >= 500 && p.price <= 1000);
  } else if (price === "high") {
    filtered = filtered.filter(p => p.price > 1000);
  }

  if (sort === "priceAsc") {
    filtered.sort((a, b) => a.price - b.price);
  } else if (sort === "priceDesc") {
    filtered.sort((a, b) => b.price - a.price);
  } else if (sort === "ratingDesc") {
    filtered.sort((a, b) => b.rating - a.rating);
  }

  renderProducts(filtered);
}

categoryFilter.addEventListener("change", applyFiltersAndSort);
priceFilter.addEventListener("change", applyFiltersAndSort);
sortOption.addEventListener("change", applyFiltersAndSort);

// Initial render
renderProducts(products);
